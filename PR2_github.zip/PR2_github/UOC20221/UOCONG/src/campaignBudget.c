#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "campaignDaily.h"
#include "campaignBudget.h"
#include "campaign.h"
#include "error.h"

// Initialize a Campaign budget data list
void campaignBudgetDataList_init(tCampaignBudgetDataList* list){
    // PR2 Ex 1a    
    //Initiate am empty list for the day
	assert(list != NULL);
	
	list->count = 0;
	list->first = NULL;
	list->last = NULL;

}

int campaignBudgetDataList_add(tCampaignBudgetDataList* list, tDate date, tCampaign* campaign) {    
    // PR2 Ex 1b
    //Variable placeholders
	tDate firstdate;
	tDate lastdate;
	bool updateRange=false;
	tCampaignDaily* pNode;
	tCampaignNode* pNext;
	
	//Is the budget available?
	if (budget_check(campaign, campaign.project) == false) {
		return E_NO_BUDGET;
	};
	
	//If the list is empty, add the new element:
	if (list->count == 0) {
		//Create a new element
		list->first = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
		assert(list->first != NULL);
		list->last = list->first;
		list->count = 1;
		// Init the new element
		campaignDaily_init(list->first, date);
		//For that date, include the campaign into the first Node:
		campaignNode_add(list->first, campaing);
	//List is not empty, we need to compare dates
	} else {
		//Search for the starting date of our list
		if (date_cmp(list->first->date, date) > 0) {
			//Date is before the others date, Campaign to be added to the left - start - of the list
			campaignDailyList_expandLeft(list, date);
			//Set start position for update the first element
			pNode = list->first;
		} else if (date_cmp(list->last->date, date) > 0) {
			//Date is wihtin range of current dates in our list, we will update on provided date
			pNode = campaignBudgetDataList_find(list, date);
			assert(pNode != NULL);
		} else {
			//Date is after last position of our list, we need to expand
			campaignDailyList_expandRight(list, date);
			pNode = list->last;
		}
		//Update the days as per clasification
		while(pNode != NULL) {
			campaignDaily_update(pNode, campaing);
			pNode = pNode->next;
		}		
	}
	//Purge the list for clean status
	
	
}

float campaignBudgetDataList_getDailyCost(tCampaignBudgetDataList* list, tDate date) {        
    // PR2 Ex 1c
    /////////////////
    return 0.0;
}

int campaignBudgetDataList_campaignNodeCounts(tCampaignBudgetDataList* list, tDate date) {
    // PR2 Ex 1d
    /////////////////    
	return 0;
}

int campaignBudgetDataList_campaignDailyCounts(tCampaignBudgetDataList* list) {
    // PR2 Ex 1d
    /////////////////    
	return 0;
}

// Release the campaignBudgetDataList
void campaignBudgetDataList_free(tCampaignBudgetDataList* list) {
    // PR2 Ex 3e
    /////////////////
}


//// AUX METHODS FOR TOP DOW//
// For any given campaign, is there budget available? //
bool budget_check (tCampaign campaign, tProject project) {
	if (campaign.cost < project.budget) {
		return true;
	} else {
		return false
	}
};

//Copy a daily to another position due to new daily date

void campaignDaily_copy(tCampaignDaily* src, tCampaignDaily* dst) {
	tCampaignNode *pNode;
	//Init the destination
	campaignDaily_init(dst, dst->date);
	// Add nodes from src daily to destination daily
	pNode = src->first;
	while(pNode != NULL) {
		campaignDaily_update(dst, pNode->elem);
		pNode = pNode->next
	}
}


//Find the CampaignDaily present for a given date
tCampaignDaily* campaignBudgetDataList_find(tCampaignBudgetDataList* list, tDate date) {
	tCampaignDaily *pNode;
	tCampaignDaily *pDate;
	assert(list != NULL);
	
	//Find the node
	pDate = NULL;
	if (list->count > 0 && date_cmp(list->first->date, date) <= 0 && date_cmp(list->first->date, date) >= 0) {
		pNode = list->first;
		while(pNode != NULL && pDate == NULL) {
			if(date_cmp(pNode->date, date) == 0) {
				//We are in the current date
				pDate = pNode;
			}
			pNode = pNode->next;
		}
	}
	return pDate;
}

//Update a list with a given campaign
void campaignDaily_update(tCampaignDaily* campaignDaily, tCampaign campaign) {
	tCampaignNode* pNode;
	tCampaignNode* pAux;
	assert(campaignDaily != NULL);
	
	//Search for a node for a given campaing
	pNode = findNode(campaignDaily->first, campaign);
	// If there is a node for that campaign, is for the same city?
	pAux = campaignNode_findCampaign(pNode, campaign);
	
	if (pNode != NULL) {
		if ( pAux!= NULL) {
			RETURN E_DUPLICATED;
			
		} else {
			campaignNode_add(&campaignDaily, campaign);
			campaign.project.budget = campaign.project.budget - campaign.cost;
		}
	} else if (campaignDaily->count == 0) {
		//There is a daily for the date with no nodes, we add it:
		campaignDaily->first = (tCampaignNode*) malloc(sizeof(tCampaignNode));
		assert(campaignDaily->first != NULL);
		campaignNode_init(&(campaignDaily->first->elem, campaign));
		campaignDaily->first->next = NULL;
		campaignDaily->count++;
	} else if (strcmp(campaignDaily->first->elem.project->code, campaign->project.code) > 0) {
		//For that date, our new node needs to be first
		pNode = campaignDaily->first;
		campaignDaily->first = (tCampaignNode*) malloc(sizeof(tCampaignNode));
		assert(campaignDaily->first != NULL);
		campaignNode_init(&(campaignDaily->first->elem, campaign));
		campaignDaily->first->next = pNode;
		campaignDaily->count++;		
	} else {
		//We need to find where the insert alphabetically the new node
		pNode = campaignDaily->first;
		while(pNode->next != NULL && strcmp(pNode->next->elem.project->code, campaign->project.code) < 0) {
			pNode = pNode->next;
		}
		pAux = pNode->next;
		pNode->next = (tCampaignNode*) malloc(sizeof(tCampaignNode));
		assert(pNode->next != NULL);
		campaignNode_init(&(pNode->next->elem, campaign));
		pNode->next->next = pAux;
		campaignDaily->count++;
	}
	// TO BE FINISH
}

//

// Extend the list adding empty day cells on left
void campaignDailyList_expandLeft(tCampaignBudgetDataList* list, tDate date) {
	tDate today;
	tCampaignDaily* pAux;
	//Select one day before the current first one
	today = list->first->date;
	date_addDay(&today, -1);
	//Iterate on the left of the current top left
	while(date_cmp(today, date) >= 0) {
		//Store current element
		pAux = list->first;
		//Add empty element first position
		list->first = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
		assert(list->first != NULL);
		list->count++;
		//Init the empty element
		campaignDaily_init(list->first, today);
		//Set prior top left as next elem
		list->first->next = pAux;
		//Return today to -1 daz
		date_addDay(&today, -1);
	}
}

// Extend the list adding occupied day cells on right:
void campaignDailyList_expandRight(tCampaignBudgetDataList* list, tDate date) {
	tDate today;

	//Select one day before the current first one
	today = list->last->date;
	date_addDay(&today, 1);
	//Iterate on the left of the current top left
	while(date_cmp(today, date) <= 0) {
		//Add empty element first position
		list->last->next = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
		assert(list->last->next != NULL);
		list->count++;
		//Init the empty element
		campaignDaily_init(list->last->next, today);
		//Copy from previous last element
		campaignDaily_copy(list->last, list->last->next);
		//Set the new last element
		list->last = list->last->next;
		//Increment today to +1 day
		date_addDay(&today, 1);
	}
}







// Extend the list to the right with the data of the last position
void campaignDailyList_expandRight(tCampaignBudgetDataList* list, tDate date) {
	
	
	
}

// Remove entries with no data on the start and end of the list
void campaignDailyList_purge(tCampaignBudgetDataList* list);



