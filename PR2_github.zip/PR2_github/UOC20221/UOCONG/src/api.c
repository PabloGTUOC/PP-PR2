#include <stdio.h>
#include <assert.h>
#include "csv.h"
#include "api.h"

#include <string.h>
#include "person.h"
#include "project.h"
#include "campaign.h"

#define FILE_READ_BUFFER_SIZE 2048

// Get the API version information
const char* api_version() {
    return "UOC PP 20221";
}

// Load data from a CSV file. If reset is true, remove previous data
tApiError api_loadData(tApiData* data, const char* filename, bool reset) {
    tApiError error;
    FILE *fin;    
    char buffer[FILE_READ_BUFFER_SIZE];
    tCSVEntry entry;
    
    // Check input data
    assert( data != NULL );
    assert(filename != NULL);
    
    // Reset current data    
    if (reset) {
        // Remove previous information
        error = api_freeData(data);
        if (error != E_SUCCESS) {
            return error;
        }
        
        // Initialize the data
        error = api_initData(data);
        if (error != E_SUCCESS) {
            return error;
        }
    }

    // Open the input file
    fin = fopen(filename, "r");
    if (fin == NULL) {
        return E_FILE_NOT_FOUND;
    }
    
    // Read file line by line
    while (fgets(buffer, FILE_READ_BUFFER_SIZE, fin)) {
        // Remove new line character     
        buffer[strcspn(buffer, "\n\r")] = '\0';
        
        csv_initEntry(&entry);
        csv_parseEntry(&entry, buffer, NULL);
        // Add this new entry to the api Data
        error = api_addDataEntry(data, entry);
        if (error != E_SUCCESS) {
            return error;
        }
        csv_freeEntry(&entry);
    }
    
    fclose(fin);
    
    return E_SUCCESS;
}

// Initialize the data structure
tApiError api_initData(tApiData* data) {            
    //////////////////////////////////
    // Ex PR1 2b
    /////////////////////////////////
    // Check input data structure
    assert(data != NULL);
    
    // Initialize data structures
    staff_init(&(data->staff));
    projectList_init(&(data->projects));
    campaignData_init(&(data->campaignData));
        
    return E_SUCCESS;
    
    /////////////////////////////////
    // return E_NOT_IMPLEMENTED;
}

// Add a new campaign
tApiError api_addCampaign(tApiData* data, tCSVEntry entry) {
    //////////////////////////////////
    // Ex PR1 2c
    /////////////////////////////////
    tCampaign campaign;
	tCampaign* newCampaign;
	tProject* pProject;
	tProject project;
    int ret = E_SUCCESS;
        
    // Check input data structure
    assert(data != NULL);
    
    // Check the entry type
    if (strcmp(csv_getType(&entry), "CAMPAIGN") != 0) {
        return E_INVALID_ENTRY_TYPE;
    }
    
    // Check the number of fields
    if(csv_numFields(entry) != 7 && csv_numFields(entry) != 8) {
        return E_INVALID_ENTRY_FORMAT;
    }
    
    // Parse the entry
    campaign_parse(&campaign, entry);
	project_parse(&project, entry);
    	
    // Add the campaign to the data
    ret = campaignData_add(&(data->campaignData), campaign, project.code, &newCampaign);
	if (ret==E_SUCCESS) {        
		// Check if project exists
		pProject = projectList_find(data->projects, project.code);
		if (pProject == NULL) {
			// Add the project
			projectList_insert(&(data->projects), project);
			pProject = projectList_find(data->projects, project.code);
		}
		newCampaign->project = pProject;
		assert(pProject != NULL);
	}
    
    // Release temporal data
    campaign_free(&campaign);
    project_free(&project);
    return ret;
}

// Get the number of people registered on the application
int api_staffCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return staff_len(data.staff);
    /////////////////////////////////
    //return -1;
}

// Get the number of projects registered on the application
int api_projectCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return projectList_len(data.projects);    
    /////////////////////////////////
    //return -1;
}

// Get the number of campaigns registered on the application
int api_campaignCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return campaignData_len(data.campaignData);
    /////////////////////////////////
    //return -1;
}


// Free all used memory
tApiError api_freeData(tApiData* data) {
    //////////////////////////////////
    // Ex PR1 2e
    /////////////////////////////////
    staff_free(&(data->staff));
    campaignData_free(&(data->campaignData));
    projectList_free(&(data->projects));
    
    return E_SUCCESS;
    /////////////////////////////////
    //return E_NOT_IMPLEMENTED;
}


// Add a new entry
tApiError api_addDataEntry(tApiData* data, tCSVEntry entry) { 
    //////////////////////////////////
    // Ex PR1 2f
    /////////////////////////////////
    tPerson person;
        
    assert(data != NULL);
    
    // Initialize the person object
    person_init(&person);
        
    if (strcmp(csv_getType(&entry), "PERSON") == 0) {
        // Check the number of fields
        if(csv_numFields(entry) != 7) {
            return E_INVALID_ENTRY_FORMAT;
        }
        // Parse the data
        person_parse(&person, entry);
        
        // Check if this person already exists
        if (staff_find(data->staff, person.document) >= 0) {
            // Release person object
            person_free(&person);
            return E_DUPLICATED;
        }
        
        // Add the new person
        staff_add(&(data->staff), person);
        
        // Release person object
        person_free(&person);
        
    } else if (strcmp(csv_getType(&entry), "CAMPAIGN") == 0) {
        return api_addCampaign(data, entry);        
    } else {
        return E_INVALID_ENTRY_TYPE;
    }
    return E_SUCCESS;
    /////////////////////////////////
    //return E_NOT_IMPLEMENTED;
}

// Get project data
tApiError api_getProject(tApiData data, const char *name, tCSVEntry *entry) {
    //////////////////////////////////
    // Ex PR1 3a
    /////////////////////////////////
    char buffer[2048];
    tProject* project = NULL;
        
    assert(name != NULL);
    assert(entry != NULL);
    
    // Search the project
    project = projectList_find(data.projects, name);
    
    if (project == NULL) {
        return E_PROJECT_NOT_FOUND;
    }
    

    // Print data in the buffer
    sprintf(buffer, "%s;%s", project->code, project->ongCode);
    
    // Initialize the output structure
    csv_initEntry(entry);
    csv_parseEntry(entry, buffer, "PROJECT");
    
    return E_SUCCESS;
    
}

// Get Campaign
tApiError api_getCampaign(tApiData data, const char* code, const char* city, tDate date, tCSVEntry *entry) {
    //////////////////////////////////
    // Ex PR1 3b
    /////////////////////////////////
    char buffer[2048];
    int idx;
    tCampaign* campaign = NULL;
        
    assert(code != NULL);
	assert(city != NULL);
    assert(entry != NULL);
    
    // Search the campaign
    idx = campaignData_find(data.campaignData, code, city, date);
        
    if (idx < 0) {
        return E_CAMPAIGN_NOT_FOUND;
    }
    
    campaign = &data.campaignData.elems[idx];
	//“codeProject;date;city;cost;numPeople”
	
    // Print data in the buffer
    sprintf(buffer, "%s;%02d/%02d/%04d;%s;%.2f;%d", 
        campaign->project->code, campaign->date.day, campaign->date.month, campaign->date.year,
        campaign->city, campaign->cost, campaign->numPeople
    );
    
    // Initialize the output structure
    csv_initEntry(entry);
    csv_parseEntry(entry, buffer, "CAMPAIGN");
    
    return E_SUCCESS;
    
}

// Get registered projects
tApiError api_getProjects(tApiData data, tCSVData *projects) {
    //////////////////////////////////
    // Ex PR1 3c
    /////////////////////////////////
    char buffer[2048];
    tProjectNode *pNode = NULL;
    
    csv_init(projects);
        
    pNode = data.projects.first;
    while(pNode != NULL) {
        sprintf(buffer, "%s;%s", pNode->project.code, pNode->project.ongCode);
        csv_addStrEntry(projects, buffer, "PROJECT");
        pNode = pNode->next;
    }    
    
    return E_SUCCESS;
}

// Get campaigns
tApiError api_getCampaigns(tApiData data, tCSVData *campaigns) {
    //////////////////////////////////
    // Ex PR1 3d
    /////////////////////////////////
    char buffer[2048];
    int idx;
    
    csv_init(campaigns);
    for(idx=0; idx<data.campaignData.count ; idx++) {
        sprintf(buffer, "%s;%02d/%02d/%04d;%s;%.2f;%d", 
            data.campaignData.elems[idx].project->code,
			data.campaignData.elems[idx].date.day, data.campaignData.elems[idx].date.month, data.campaignData.elems[idx].date.year,
            data.campaignData.elems[idx].city, data.campaignData.elems[idx].cost, data.campaignData.elems[idx].numPeople
        );
        csv_addStrEntry(campaigns, buffer, "CAMPAIGN");
    }
    
    return E_SUCCESS;
}


// Get the number of ngos registered on the application
int api_ongCount(tApiData data) {
    //////////////////////////////////
    // Ex PR2 3c        
    /////////////////////////////////
    return -1;
}
