#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "campaignBudget.h"
#include "campaignDaily.h"
#include "campaign.h"
#include "error.h"

void campaignDaily_init(tCampaignDaily* campaignDaily, tDate date) {
    assert(campaignDaily != NULL);
    campaignDaily->count = 0;
    campaignDaily->first = NULL;
    campaignDaily->next = NULL;
    campaignDaily->date = date;
}

void campaignDaily_free(tCampaignDaily* campaignDaily) {
   tCampaignNode* pNode;    
   assert(campaignDaily != NULL);
    
    pNode = campaignDaily->first;
    
    while (pNode != NULL) {
        campaignDaily->first = pNode->next;
        free(pNode);
        pNode = campaignDaily->first;
    }
    
    campaignDaily->count = 0;
    campaignDaily->first = NULL;
}

float campaignDaily_getDailyCost(tCampaignDaily* campaignDaily) {
    tCampaignNode* pNext;
    float dailyCost = 0.0;
    
    pNext = campaignDaily->first;
    
    while (pNext!=NULL) {
        dailyCost+=pNext->elem->cost;
        pNext = pNext->next;
    }
    return dailyCost;
}

//void campaignDaily_copy(tCampaignDaily* src, tCampaignDaily* dst){}

// Remove all  entries with no campaignNodes
void campaignDaily_purge(tCampaignDaily* campaignDaily) {
    tCampaignNode *pNode;
    tCampaignNode *pAux;
    //bool is_first = true;
    
    assert(campaignDaily != NULL);
    
    pNode = campaignDaily->first;
    pAux = NULL;
    
    while (pNode != NULL) {
        if (pNode->elem->project->budget == 0) {
            if (pAux != NULL) {
                pAux->next = pNode->next;
                free(pNode); 
                pNode = pAux->next;
            } else {
                campaignDaily->first = pNode->next;
                free(pNode);
                pNode = campaignDaily->first;
                pAux = NULL;                
            }
            campaignDaily->count--;                        
        } else {
            pAux = pNode;
            pNode = pNode->next;                    
        }
    }
}


tCampaignNode* campaignNode_newNode(tCampaign* campaign) {
	tCampaignNode* campaignNode;
	campaignNode = (tCampaignNode*) malloc(sizeof(tCampaignNode));
    assert(campaignNode != NULL);

    campaignNode->elem = campaign;
	campaignNode->next = NULL;
	
	return campaignNode;
}

// Initialize a campaign node element
void campaignNode_init(tCampaignDaily* campaignDaily, tCampaign* campaign) {
    assert(campaignDaily != NULL);

	campaignDaily->first = campaignNode_newNode(campaign);
	campaignDaily->count = 1;
}

tCampaignNode* findNode(tCampaignNode* campaignNode, tCampaign* campaign) {
	assert(campaignNode!=NULL);
	tCampaignNode* next;
    tCampaignNode* prev;
	tCampaignNode* current;
    char* code1;
    char* code2;
    bool found;
	
	current = campaignNode;
	next = campaignNode->next;
    code1 = campaign->project->code;
    code2 = current->elem->project->code;
    //found = strcmp(campaign->project->code, current->elem->project->code)>0;
    found = strcmp(code1, code2);
	prev = NULL;
	while (next!=NULL && !found) {
		prev = current;
		current = next;
		next = prev->next;
        found = strcmp(campaign->project->code, current->elem->project->code)>0;
	}
	
	return (found?prev:current);
}

bool campaigNode_compareCampaigns(tCampaign* campaign1, tCampaign* campaign2) {
	return (campaign1->city == campaign2->city && 
	        campaign1->project->code == campaign2->project->code);
}

tCampaignNode* campaignNode_findCampaign(tCampaignNode* campaignNode, tCampaign* campaign) {
	assert(campaignNode!=NULL);
	tCampaignNode* next;
	tCampaignNode* current;
	tCampaignNode* _aux;
	bool found = false;
	
	
	current = campaignNode;
	next = campaignNode->next;
	
	found = campaigNode_compareCampaigns(current->elem, campaign);
	
	while (!found && next!=NULL) {
		_aux = current;
		current = next;
		next = _aux->next;
		found = campaigNode_compareCampaigns(current->elem, campaign);
	}
	
	return (found?current:NULL);
}


void campaignNode_add(tCampaignDaily* campaignDaily, tCampaign* campaign) {
    tCampaignNode *pNode;
    tCampaignNode *_aux;
	assert(campaignDaily != NULL);
	
	if (campaignDaily->first != NULL) {
        pNode = findNode(campaignDaily->first, campaign);
        if (pNode == NULL) {
            _aux = campaignDaily->first;
            campaignDaily->first = campaignNode_newNode(campaign);
            campaignDaily->first->next = _aux;
        } 
        else {
            _aux = pNode;
            pNode->next = campaignNode_newNode(campaign);
            pNode->next->next=_aux->next;            
        }
    } else {
        campaignDaily->first = campaignNode_newNode(campaign);
    }
	campaignDaily->count++;
}


