#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "ong.h"


// Initialize a NGO
void ong_init(tONG* ong, const char* code, const char* name){ 
	// PR2 Ex 2a
    /////////////////
}

// Release a NGO's data
void ong_free(tONG* ong){
	// PR2 Ex 2b
    /////////////////
}

// Initialize a list of ngos
void ongList_init(tONGList* list){
	// PR2 Ex 2c
    /////////////////
}

// Release a list of ngos
void ongList_free(tONGList* list){
	// PR2 Ex 2d
    /////////////////
}

// Insert a new ngo
void ongList_insert(tONGList* list, const char* code, const char* name){ 	    
	// PR2 Ex 2e
    /////////////////
}

// Find a ngo
tONG* ongList_find(tONGList* list, const char* code){
	// PR2 Ex 2f
    /////////////////
    
    return NULL;
}
    
    
void ongList_print(tONGList* list){
	tONGNode *pNode;    
    tONG *pONG;    
    
    assert(list != NULL);
    
    pNode = list->first;
    pONG = NULL;
    while(pNode != NULL && pONG == NULL) {        
        printf("ong %s code %s\n",pNode->elem.name,pNode->elem.code);      
        pNode = pNode->next;        
    }
}
