#ifndef __PROJECT__H
#define __PROJECT__H

#include "csv.h"
#include "date.h"

// Project data
typedef struct _tProject {
    char *code;
    char *ongCode;
    float budget;
} tProject;

// Node of a list of projects
typedef struct _tProjectNode {    
    tProject project;
    struct _tProjectNode *next;
} tProjectNode;

// List of projects
typedef struct _tProjectList {    
    tProjectNode* first;
    int count;
} tProjectList;


// Initialize project structure
void project_init(tProject* project, const char* code, const char*ongCode, float budget);

// Parse input from CSVEntry
void project_parse(tProject* project, tCSVEntry entry);

// Release project data
void project_free(tProject* project);

// Copy the data of a project from the source to destination
void project_cpy(tProject* destination, tProject source);

// Initialize the compaign's list
void projectList_init(tProjectList* projectList);

// Remove all elements
void projectList_free(tProjectList* projectList);

// Get the number of projects
int projectList_len(tProjectList projectList);

// Find a project in the list of projects
tProject* projectList_find(tProjectList list, const char* name);

// Add a new project
void projectList_insert(tProjectList* list, tProject project);

// Remove a project
void projectList_del(tProjectList* list, const char* project);

#endif // __PROJECT__H
