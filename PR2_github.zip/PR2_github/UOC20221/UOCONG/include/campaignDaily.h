#ifndef __CAMPAIGN_DAILY__H
#define __CAMPAIGN_DAILY__H

#include "campaign.h"
#include "campaignBudget.h"
#include "project.h"
#include "date.h"
#include "person.h"



// Initialize a campaign daily element
void campaignDaily_init(tCampaignDaily* campaignDaily, tDate date);

// Remove a daily element data
void campaignDaily_free(tCampaignDaily* campaignDaily);

// Find a campaign node for a given daily stock
tCampaignNode* campaignDaily_findCampaignNode(tCampaignDaily* campaignDaily, tCampaign* campaign);


float campaignDaily_getDailyCost(tCampaignDaily* campaignDaily);


// Remove all campaign entries with no budget
void campaignDaily_purge(tCampaignDaily* campaignDaily);

// Copy the contents from source to destination
//void campaignDaily_copy(tCampaignDaily* src, tCampaignDaily* dst);

// Find the stock for a given date
tCampaignDaily* campaignDailyList_find(tCampaignBudgetDataList* list, tDate date);


// Extend the list adding empty day cells on left
void campaignDailyList_expandLeft(tCampaignBudgetDataList* list, tDate date);

// Extend the list to the right with the data of the last position
void campaignDailyList_expandRight(tCampaignBudgetDataList* list, tDate date);

// Remove entries with no data on the start and end of the list
void campaignDailyList_purge(tCampaignBudgetDataList* list);

// Initialize the campaignDaily nodes list
void campaignNode_init(tCampaignDaily* campaignDaily, tCampaign* campaign);

void campaignNode_add(tCampaignDaily* campaignDaily, tCampaign* campaign);

tCampaignNode* campaignNode_findCampaign(tCampaignNode* campaignNode, tCampaign* campaign);

#endif // __CAMPAIGN_DAILY__H