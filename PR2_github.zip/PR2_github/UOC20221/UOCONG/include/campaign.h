#ifndef __CAMPAIGN__H
#define __CAMPAIGN__H

#include "csv.h"
#include "date.h"
#include "project.h"
#include "person.h"


// Campaign 
typedef struct _tCampaign {
    tProject* project;
    tDate date;
    char* city;
    float cost; 
    int numPeople;
    tStaff* staff;
} tCampaign;

// Table of campaignData
typedef struct _tCampaignData {    
    tCampaign* elems;
    int count;
} tCampaignData;


// Initialize campaign data
void campaign_init(tCampaign* campaign, tProject* project, tDate date, const char* city, float cost, int people);

// Release campaign data
void campaign_free(tCampaign* compaign);

// Copy the data of a campaign from the source to destination
void campaign_cpy(tCampaign* destination, tCampaign source);

// Parse input from CSVEntry
void campaign_parse(tCampaign* compaign, tCSVEntry entry);

// Initialize the campaing data
void campaignData_init(tCampaignData* data);

// Remove all elements
void campaignData_free(tCampaignData* data);

// Get the number of campaings
int campaignData_len(tCampaignData data);

// Add a new campaign
int campaignData_add(tCampaignData* data, tCampaign campaign, const char* projectCode, tCampaign** newCampaign);

// Remove campaign
void campaignData_del(tCampaignData* data, const char* code, const char* city, tDate date, int numPeople, float cost);

// Return the position of a campaign entry with provided information. -1 if it does not exist
int campaignData_find(tCampaignData data, const char* code, const char* city, tDate date);

// Return the campaign entry with provided information. NULL if it does not exist
tCampaign* campaignData_findCampaign(tCampaignData data, const char* code, const char*city, tDate date);

#endif // __CAMPAIGN__H
